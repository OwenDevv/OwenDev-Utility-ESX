fx_version 'adamant'

game 'gta5'
author 'OwenDev'

version '1.1.0'

client_scripts {
     "config.lua",
     "client/*.lua"
}

server_scripts {
     "config.lua",
     "server/*.lua"
}
