ESX = exports["es_extended"]:getSharedObject()

--###--^-Réduction de PNJ hostiles-^--###

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        -- Stop Spawn
        SetCreateRandomCops(false)
        SetCreateRandomCopsNotOnScenarios(false)
        SetCreateRandomCopsOnScenarios(false)
        SetGarbageTrucks(false)
        SetRandomBoats(false)
        SetVehicleDensityMultiplierThisFrame(0.4)
        SetPedDensityMultiplierThisFrame(0.3)
        SetRandomVehicleDensityMultiplierThisFrame(0.1)
        SetScenarioPedDensityMultiplierThisFrame(0.0, 0.0)
        SetParkedVehicleDensityMultiplierThisFrame(0.1)

        -- Clear NPC
        local coords = GetEntityCoords(PlayerPedId())
        ClearAreaOfVehicles(coords.x, coords.y, coords.z, 1000, false, false, false, false, false)
        RemoveVehiclesFromGeneratorsInArea(coords.x - 500.0, coords.y - 500.0, coords.z - 500.0, coords.x + 500.0, coords.y + 500.0, coords.z + 500.0)
    end
end)

--###--^-Empêche l'AFK via la caméra-^--###

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(10000) -- Moins fréquent
        DisableIdleCamera(true)
    end
end)

--###--^-Anti Buny-^--###

local NumberJump = 15

Citizen.CreateThread(function()
    local Jump = 0
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()

        if IsPedOnFoot(ped) and not IsPedSwimming(ped) and (IsPedRunning(ped) or IsPedSprinting(ped)) 
        and not IsPedClimbing(ped) and IsPedJumping(ped) and not IsPedRagdoll(ped) then

            Jump = Jump + 1

            if Jump == NumberJump then
                -- Met en mode ragdoll
                SetPedToRagdoll(ped, 5000, 1400, 2)

                -- Réduit la santé
                local currentHealth = GetEntityHealth(ped)
                local damageAmount = 1 -- Quantité de vie à perdre
                SetEntityHealth(ped, currentHealth - damageAmount)

                -- Réinitialise le compteur de sauts
                Jump = 0
            end

        else 
            Citizen.Wait(500)
        end
    end
end)

--##Desactive l attaque avec R 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(5) -- A Short Daily of 5 MS
		DisableControlAction(0, 140, true) -- Disable the Light Dmg Contr ol
	end
end)

-----##Desactive Coup de cross


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
		local ped = PlayerPedId()
            	if IsPedArmed(ped, 6) then
	    	DisableControlAction(1, 140, true)
            	DisableControlAction(1, 141, true)
            	DisableControlAction(1, 142, true)
        end
    end
end)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        print("^2[OwenDev] ^0Scripts faits par OwenDev.")
        
        TriggerEvent('chat:addMessage', {
            color = {0, 255, 0}, 
            multiline = true,
            args = {"[OwenDev]", "Scripts faits par OwenDev."}
        })
    end
end)
